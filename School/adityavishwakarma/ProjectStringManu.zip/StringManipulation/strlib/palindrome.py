def isPalindrome(st):
	rev_st = st[::-1]
	return rev_st == st