def toascii(string):
    lst = []
    for i in string:
        lst.append(ord(i))
    return lst

